import React, { Component } from 'react';
import { Card, Icon, Avatar } from 'antd';
import { Card, Col, Row } from 'antd';



export class PanelMembers extends Component {
  constructor() {

  }

  render() {
    return (
      <div className="fourth-half">
         
      </div>
    );
  }
}